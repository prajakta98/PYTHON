import matplotlib
import matplotlib.pyplot as plt
import numpy as np
from pylab import *
x=np.linspace(0,5,10) 

#fig, ax=plt.subplots()
#ax.plot(x, x**2, label="y=x**2")
#ax.plot(x, x**3, label="y=x**3")
#ax.legend(loc=2)
#ax.set_xlabel('x')
#ax.set_ylabel('y')
#ax.set_title('title')

#fig, ax=plt.subplots(figsize=(12,6))
#ax.plot(x,x+1,color="blue",linewidth=0.25)
#ax.plot(x,x+2,color="blue",linewidth=0.50)
#ax.plot(x,x+3,color="blue",linewidth=1.00)
#ax.plot(x,x+4,color="blue",linewidth=2.00)
#plt.show()

#possible linestyle options
#ax.plot(x,x+5,color="red",lw=2,linestyle='-')
#ax.plot(x,x+6,color="red",lw=2,linestyle='-.')
#ax.plot(x,x+7,color="red",lw=2,linestyle=':')

#custom dash
#line,=ax.plot(x,x+8,color="black",lw=1.50)
#line.set_dashes([5,10,15,10])
#FORMAT: line length,space lengty,....
#5th line 10pt break 15pt line 10pt break

#ax.plot(x,x+9,color="green",lw=2,linestyle='--',marker='+')
#ax.plot(x,x+10,color="green",lw=2,linestyle='--',marker='o')
#ax.plot(x,x+11,color="green",lw=2,linestyle='--',marker='s')
#ax.plot(x,x+12,color="green",lw=2,linestyle='--',marker='1')

#ax.plot(x,x+13,color="purple",lw=1,linestyle='-',marker='o',markersize=2)
#ax.plot(x,x+14,color="purple",lw=1,linestyle='-',marker='o',markersize=4)
#ax.plot(x,x+15,color="purple",lw=1,linestyle='-',marker='o',markersize=8)
#ax.plot(x,x+16,color="purple",lw=1,linestyle='-',marker='s',markersize=8,markerfacecolor="yellow",markeredgewidth=2,markeredgecolor="blue")

print(np.random.randn(10))
n=np.array([0,1,2,3,4,5])
x=np.linspace(0,5,10)
xx=np.linspace(-0.75,1.,100)
#print(type(x))
#print(len(xx))

fig ,axes=plt.subplots(1, 3, figsize=(12,3))
axes[0].scatter(xx, xx+0.75*np.random.randn(len(xx))) 
axes[0].set_title("scatter")

axes[1].step(n, n**2, lw=2) #step graph
axes[1].set_title("step")

axes[2].bar(n,n**2,align="centre", width=0.5, alpha=0.5) #default width 0.8 
axes[2].set_title("bar")
plt.show()