import matplotlib
import matplotlib.pyplot as plt
import numpy as np
from pylab import *
x=np.linspace(0,5,10) 
#print(x)
#print(type(x))
y=x**2
#fig=plt.figure()
#axes=fig.add_axes([0.1,0.1,0.8,0.8])
#axes.set_xlabel('x')
#axes.set_title('title')
#axes.set_ylabel('y')
##plt.show()
fig=plt.figure()
axes1=fig.add_axes([0.1,0.1,0.8,0.8])
axes2=fig.add_axes([0.2,0.5,0.4,0.3])
#mainfigure
axes1.plot(x,y,'r')
axes1.set_xlabel('x')
axes1.set_ylabel('y')
axes1.set_title('title')
#insert
axes2.plot(x,y,'g')
axes2.set_xlabel('y')
axes2.set_ylabel('x')
axes2.set_title('insert title')
plt.show()











