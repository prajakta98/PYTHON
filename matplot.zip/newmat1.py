import matplotlib
import matplotlib.pyplot as plt
import numpy as np
from pylab import *
x=np.linspace(0,5,10) 
y=x**2

#fig,axes=plt.subplots(nrows=1, ncols=2)
#ax=axes[0]
#ax.plot(x,y,'r')
#ax.set_xlabel('x')
#ax.set_ylabel('y')
#ax.set_title('title')

#print(axes)
#print(type(fig))
#print(type(axes))
#plt.show()

#ax1=axes[1]
#ax1.plot(y,x,'g')
#ax1.set_xlabel('y')
#ax1.set_ylabel('x')
#ax1.set_title('subtitle')
#print(axes)
#plt.show()

fig,axes=plt.subplots(figsize=(12,3))
print(axes)
axes.plot(x,y,'r')
axes.set_xlabel('x')
axes.set_ylabel('y')
axes.set_title('title')
plt.show()
fig.savefig("file1.png")
fig.savefig("file2.png",dpi=500)